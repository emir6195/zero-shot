from setuptools import setup

setup(
    name='zero_shot_emir',
    version='1.0.1',
    packages=['lib'],
)
